#ifndef NPC_H
# define NPC_H

#include <stdio.h> 
#include <stdlib.h>
#include <stdint.h>
#include "dims.h"

typedef struct dungeon dungeon_t;
typedef struct character character_t;
typedef uint32_t npc_characteristics_t;

typedef struct dungeon dungeon_t;
typedef struct npc npc_t;
typedef struct pc pc_t;


typedef struct character {
  npc_t *npc;
  pc_t *pc;
  char symbol;
  pair_t position;
  uint32_t alive;                            
  uint32_t sequence_number;
  int32_t speed;
} character_t;

typedef struct npc {
  pair_t chase;
  uint32_t move;
  npc_characteristics_t characteristics;

} npc_t;

void MOB_INIT(dungeon_t *d);
void MOB_DEAD(npc_t *n);
void MOP_move_select(dungeon_t *d, character_t *c, pair_t next);
uint32_t ISNPC(dungeon_t *d);
void MOB_ALIVE(void *v);
#endif
