#ifndef MOVE_H
#define MOVE_H
#include <stdint.h>
#include "dims.h"
#include <stdio.h>
#include <stdlib.h>
#include "dungeon.h"
#include "npc.h"
typedef struct dungeon dungeon_t;
typedef struct character character_t;
uint32_t cornor(dungeon_t *d, character_t *c);
void moves(dungeon_t *d);
void closer(character_t *c, pair_t dir);
#endif
