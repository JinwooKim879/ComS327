#ifndef EVENT_H
# define EVENT_H
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "dungeon.h"

typedef struct character character_t;



typedef enum event_type {
  turn_up,
} event_type_t;

typedef struct event {
  uint32_t time;
  uint32_t sequence;
  event_type_t type;
  character_t *c;

} event_t;

void event_delete(void *e);
event_t *event_set(dungeon_t *d, event_type_t etype, void *v, uint32_t add);
event_t *update_event(dungeon_t *d, event_t *e, uint32_t add);
int32_t compare_events(const void *event1, const void *event2);


#endif
