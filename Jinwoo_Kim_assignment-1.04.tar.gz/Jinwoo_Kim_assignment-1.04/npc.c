#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "string.h"
#include "utils.h"
#include "npc.h"
#include "dungeon.h"
#include "move.h"
#include "path.h"
#include "event.h"



/*According to the professor's recommandation, *
 *I used Bresenham's Algorithm from online source*/
uint32_t bresenham(dungeon_t *d, character_t *look, character_t *seen)
{
  pair_t pre, post;
  pair_t well, bad;
  int16_t pos1, pos2, pos3, index;

  pre[dim_x] = look->position[dim_x];
  pre[dim_y] = look->position[dim_y];
  post[dim_x] = seen->position[dim_x];
  post[dim_y] = seen->position[dim_y];



  if (post[dim_x] > pre[dim_x]) {
    well[dim_x] = post[dim_x] - pre[dim_x];
    bad[dim_x] = 1;
  } else {
    well[dim_x] = pre[dim_x] - post[dim_x];
    bad[dim_x] = -1;
  }

  if (post[dim_y] > pre[dim_y]) {
    well[dim_y] = post[dim_y] - pre[dim_y];
    bad[dim_y] = 1;
  } else {
    well[dim_y] = pre[dim_y] - post[dim_y];
    bad[dim_y] = -1;
  }

  if (well[dim_x] > well[dim_y]) {
    pos1 = well[dim_y] + well[dim_y];
    pos3 = pos1 - well[dim_x];
    pos2 = pos3 - well[dim_x];
    for (index = 0; index <= well[dim_x]; index++) {
      pre[dim_x] += bad[dim_x];
      if (pos3 < 0) {
        pos3 += pos1;
      } else {
        pos3 += pos2;
        pre[dim_y] += bad[dim_y];
      }
    }
    return 1;
  } else {
    pos1 = well[dim_x] + well[dim_x];
    pos3 = pos1 - well[dim_y];
    pos2 = pos3 - well[dim_y];
    for (index = 0; index <= well[dim_y]; index++) {
      pre[dim_y] += bad[dim_y];
      if (pos3 < 0) {
        pos3 += pos1;
      } else {
        pos3 += pos2;
        pre[dim_x] += bad[dim_x];
      }
    }
    return 1;
  }

  return 1;
}
void MOB_DEAD(npc_t *n)
{
  if (n) {
    free(n);
  }
}

void MOB_ALIVE(void *is)
{
  character_t *c;
  if (is) {
    c = is;
    if (c->npc) {
      MOB_DEAD(c->npc);
    }
  }
}


void MOB_INIT(dungeon_t *d)
{
  uint32_t ISIN;
  pair_t gen;
  int i;
  character_t *monster;

  const static char symbol[] = "0123456789abcdef";

  d->num_monsters = d->max_monsters;

  for (i = 0; i < d->num_monsters; i++) {
    monster = malloc(sizeof (*monster));
    memset(monster, 0, sizeof (*monster));
    ISIN = rand_range(1, d->num_rooms - 1);


    gen[dim_y] = rand_range(d->rooms[ISIN].position[dim_y],
	       (d->rooms[ISIN].position[dim_y] + d->rooms[ISIN].size[dim_y] - 1));
    gen[dim_x] = rand_range(d->rooms[ISIN].position[dim_x],
	       (d->rooms[ISIN].position[dim_x] + d->rooms[ISIN].size[dim_x] - 1));


    while (d->character[gen[dim_y]][gen[dim_x]]);
    monster->position[dim_y] = gen[dim_y];
    monster->position[dim_x] = gen[dim_x];
    d->character[gen[dim_y]][gen[dim_x]] = monster;


    monster->pc = NULL;
    monster->alive = 1;
    monster->speed = rand_range(5, 20);
    monster->npc = malloc(sizeof (*monster->npc));
    monster->npc->characteristics = rand() & 0x0000000f;
    monster->sequence_number = ++d->character_sequence_number;
    

    monster->symbol = symbol[monster->npc->characteristics];
    monster->npc->move = 0;
    d->character[gen[dim_y]][gen[dim_x]] = monster;
    heap_insert(&d->events, event_set(d, turn_up, monster, 0));
  }
}

void MOP_move_tunnel(dungeon_t *d, character_t *c, pair_t next)
{
  int check = 1;
  pair_t move;
  union {
    uint32_t index;
    uint8_t arr[4];
  } round;
    move[dim_y] = next[dim_y];
    move[dim_x] = next[dim_x];
  while (mappair(move) == ter_wall_immutable){
    move[dim_y] = next[dim_y];
    move[dim_x] = next[dim_x];
    round.index = rand();
    if (round.arr[0] > (255/3)) {
      if (round.arr[0] & check) {
        move[dim_y]--;
      } else {
        move[dim_y]++;
      }
    }
    if (round.arr[1] > (255/3)) {
      if (round.arr[1] & check) {
        move[dim_x]--;
      } else {
        move[dim_x]++;
      }
    }
  }


}

void MOP_move(dungeon_t *d, character_t *c, pair_t next)
{
  int check = 1;
  pair_t move;
  union {
    uint32_t index;
    uint8_t arr[4];
  } round;
    move[dim_y] = next[dim_y];
    move[dim_x] = next[dim_x];
  while (mappair(move) < ter_floor){
    move[dim_y] = next[dim_y];
    move[dim_x] = next[dim_x];
    round.index = rand();
    if (round.arr[0] > (255/3)) {
      if (round.arr[0] & check) {
        move[dim_y]--;
      } else {
        move[dim_y]++;
      }
    }
    if (round.arr[1] > (255/3)) {
      if (round.arr[1] & check) {
        move[dim_x]--;
      } else {
        move[dim_x]++;
      }
    }
  }
  next[dim_y] = move[dim_y];
  next[dim_x] = move[dim_x];
}

void line_of_sight(dungeon_t *d, character_t *c, pair_t next)
{
  pair_t dir;

  dir[dim_y] = d->pc.position[dim_y] - c->position[dim_y];
  dir[dim_x] = d->pc.position[dim_x] - c->position[dim_x];
  if (dir[dim_y]) 
    {
    dir[dim_y] /= abs(dir[dim_y]);
    }
  if (dir[dim_x]) 
    {
    dir[dim_x] /= abs(dir[dim_x]);
    }
  if (mapxy(next[dim_x] + dir[dim_x],next[dim_y] + dir[dim_y]) >= ter_floor) 
    {
    next[dim_x] += dir[dim_x];
    next[dim_y] += dir[dim_y];
    } 
  else if (mapxy(next[dim_x] + dir[dim_x], next[dim_y]) >= ter_floor) 
    {
    next[dim_x] += dir[dim_x];
    } 
  else if (mapxy(next[dim_x], next[dim_y] + dir[dim_y]) >= ter_floor) 
    {
    next[dim_y] += dir[dim_y];
    }
}

void line_of_sight_different(dungeon_t *d,character_t *c,pair_t next)
{
  pair_t move;
  int limit = 60;
  move[dim_y] = d->pc.position[dim_y] - c->position[dim_y];
  move[dim_x] = d->pc.position[dim_x] - c->position[dim_x];
  if (move[dim_y]) 
    {
    move[dim_y] /= abs(move[dim_y]);
    }
  if (move[dim_x]) 
    {
    move[dim_x] /= abs(move[dim_x]);
    }
  move[dim_x] += next[dim_x];
  move[dim_y] += next[dim_y];
  if (hardnesspair(move) <= limit) 
    {
    if (hardnesspair(move)) 
      {
      hardnesspair(move) = 0;
      mappair(move) = ter_floor_hall;
      dijkstra(d);
      dijkstra_tunnel(d);
      }
    next[dim_x] = move[dim_x];
    next[dim_y] = move[dim_y];
  } 
  else 
    {
    hardnesspair(move) = hardnesspair(move) - limit;
    }
}

void MOP_EIGHT_DIR(dungeon_t *d, character_t *c, pair_t next)
{
 
  //four direction
  if (d->pc_distance[next[dim_y] - 1][next[dim_x]] < d->pc_distance[next[dim_y]][next[dim_x]]) {
    next[dim_y]--;
    return;
  }
  if (d->pc_distance[next[dim_y] + 1][next[dim_x]] < d->pc_distance[next[dim_y]][next[dim_x]]) {
    next[dim_y]++;
    return;
  }
  if (d->pc_distance[next[dim_y]][next[dim_x] + 1] < d->pc_distance[next[dim_y]][next[dim_x]]) {
    next[dim_x]++;
    return;
  }
  if (d->pc_distance[next[dim_y]][next[dim_x] - 1] < d->pc_distance[next[dim_y]][next[dim_x]]) {
    next[dim_x]--;
    return;
  }

  //corner
  if (d->pc_distance[next[dim_y] - 1][next[dim_x] + 1] < d->pc_distance[next[dim_y]][next[dim_x]]) {
    next[dim_y]--;
    next[dim_x]++;
    return;
  }
  if (d->pc_distance[next[dim_y] + 1][next[dim_x] + 1] < d->pc_distance[next[dim_y]][next[dim_x]]) {
    next[dim_y]++;
    next[dim_x]++;
    return;
  }
  if (d->pc_distance[next[dim_y] - 1][next[dim_x] - 1] < d->pc_distance[next[dim_y]][next[dim_x]]) {
    next[dim_y]--;
    next[dim_x]--;
    return;
  }
  if (d->pc_distance[next[dim_y] + 1][next[dim_x] - 1] < d->pc_distance[next[dim_y]][next[dim_x]]) {
    next[dim_y]++;
    next[dim_x]--;
    return;
  }
  
}

//not everything, stupid
static void MOP_move_00(dungeon_t *d, character_t *c, pair_t next)
{
  if (bresenham(d, c, &d->pc)) {
    c->npc->chase[dim_y] = d->pc.position[dim_y];
    c->npc->chase[dim_x] = d->pc.position[dim_x];
    line_of_sight(d, c, next);
  } else {
    MOP_move(d, c, next);
  }
}

//only intelligence
static void MOP_move_01(dungeon_t *d, character_t *c, pair_t next)
{
  if (bresenham(d, c, &d->pc)) {
    c->npc->chase[dim_y] = d->pc.position[dim_y];
    c->npc->chase[dim_x] = d->pc.position[dim_x];
    c->npc->move = 1;
    line_of_sight(d, c, next);
  } else if (c->npc->move) {
    line_of_sight(d, c, next);
  }
  if ((next[dim_x] == c->npc->chase[dim_x]) && (next[dim_y] == c->npc->chase[dim_y])) {
    c->npc->move = 0;
  }
}

//teleport
static void MOP_move_02(dungeon_t *d, character_t *c, pair_t next)
{
  c->npc->chase[dim_y] = d->pc.position[dim_y];
  c->npc->chase[dim_x] = d->pc.position[dim_x];
  line_of_sight(d, c, next);
}

//intelligence and teleporter
static void MOP_move_03(dungeon_t *d, character_t *c, pair_t next)
{
  MOP_EIGHT_DIR(d, c, next);
}

//Digger
static void MOP_move_04(dungeon_t *d, character_t *c, pair_t next)
{
  if (bresenham(d, c, &d->pc)) {
    c->npc->chase[dim_y] = d->pc.position[dim_y];
    c->npc->chase[dim_x] = d->pc.position[dim_x];
    line_of_sight(d, c, next);
  } else {
    MOP_move_tunnel(d, c, next);
  }
}

//Smart, Digger
static void MOP_move_05(dungeon_t *d, character_t *c, pair_t next)
{
  if (bresenham(d, c, &d->pc)) {
    c->npc->chase[dim_y] = d->pc.position[dim_y];
    c->npc->chase[dim_x] = d->pc.position[dim_x];
    c->npc->move = 1;
    line_of_sight(d, c, next);
  } else if (c->npc->move) {
    line_of_sight_different(d, c, next);
  }
  if ((next[dim_x] == c->npc->chase[dim_x]) && (next[dim_y] == c->npc->chase[dim_y])) {
    c->npc->move = 0;
  }
}

//Tele, digger
static void MOP_move_06(dungeon_t *d, character_t *c, pair_t next)
{
  c->npc->chase[dim_y] = d->pc.position[dim_y];
  c->npc->chase[dim_x] = d->pc.position[dim_x];
  line_of_sight_different(d, c, next);
}

//Intelligence, Teleporter, digger.
static void MOP_move_07(dungeon_t *d, character_t *c, pair_t next)
{
  MOP_EIGHT_DIR(d, c, next);
}

//not at all but crazy.
static void MOP_move_08(dungeon_t *d, character_t *c, pair_t next)
{
  if (rand() & 1) {
    MOP_move(d, c, next);
  } else {
    MOP_move_00(d, c, next);
  }
}

//Intelligence, crazy
static void MOP_move_09(dungeon_t *d, character_t *c, pair_t next)
{
  if (rand() & 1) {
    MOP_move(d, c, next);
  } else {
    MOP_move_01(d, c, next);
  }
}

//tele, crazy
static void MOP_move_0a(dungeon_t *d, character_t *c, pair_t next)
{
  if (rand() & 1) {
    MOP_move(d, c, next);
  } else {
    MOP_move_02(d, c, next);
  }
}

//Intelligence, teleporter, crazy
static void MOP_move_0b(dungeon_t *d, character_t *c, pair_t next)
{
  if (rand() & 1) {
    MOP_move(d, c, next);
  } else {
    MOP_move_03(d, c, next);
  }
}

//digger and crazy
static void MOP_move_0c(dungeon_t *d, character_t *c, pair_t next)
{
  if (rand() & 1) {
    MOP_move_tunnel(d, c, next);
  } else {
    MOP_move_04(d, c, next);
  }
}

//Intelligence, digger, crazy
static void MOP_move_0d(dungeon_t *d, character_t *c, pair_t next)
{
  if (rand() & 1) {
    MOP_move_tunnel(d, c, next);
  } else {
    MOP_move_05(d, c, next);
  }
}

//Teleporter, digger, crazy
static void MOP_move_0e(dungeon_t *d, character_t *c, pair_t next)
{
  if (rand() & 1) {
    MOP_move_tunnel(d, c, next);
  } else {
    MOP_move_06(d, c, next);
  }
}

//ultra monster
static void MOP_move_0f(dungeon_t *d, character_t *c, pair_t next)
{
  if (rand() & 1) {
    MOP_move_tunnel(d, c, next);
  } else {
    MOP_move_07(d, c, next);
  }
}






void (*putput[])(dungeon_t *d, character_t *c, pair_t next) = {
  MOP_move_00, MOP_move_01, MOP_move_02, MOP_move_03,
  MOP_move_04, MOP_move_05, MOP_move_06, MOP_move_07,
  MOP_move_08, MOP_move_09, MOP_move_0a, MOP_move_0b,
  MOP_move_0c, MOP_move_0d, MOP_move_0e, MOP_move_0f,
};

void MOP_move_select(dungeon_t *d, character_t *c, pair_t next)
{
  next[dim_y] = c->position[dim_y];
  next[dim_x] = c->position[dim_x];
  putput[c->npc->characteristics](d, c, next);
}

uint32_t ISNPC(dungeon_t *d)
{
  return d->num_monsters;
}
