#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "string.h"

#include "dungeon.h"
#include "pc.h"
#include "utils.h"
#include "move.h"
#include "path.h"

void ISDEAD(pc_t *pc)
{
  if (pc) {
    free(pc);
  }
}
uint32_t ISPC(dungeon_t *d)
{
  return d->pc.alive;
}
void starting(dungeon_t *player)
{
  memset(&player->pc, 0, sizeof (player->pc));
  player->pc.symbol = '@';
  player->pc.position[dim_y] = 
    rand_range(player->rooms->position[dim_y],
    (player->rooms->position[dim_y] + player->rooms->size[dim_y] - 1));
  player->pc.position[dim_x] = 
    rand_range(player->rooms->position[dim_x],
    (player->rooms->position[dim_x] + player->rooms->size[dim_x] - 1));
  player->pc.speed = 10;
  player->pc.alive = 1;
  player->pc.sequence_number = 0;
  player->pc.pc = calloc(1, sizeof (*player->pc.pc));
  player->pc.npc = NULL;
}


