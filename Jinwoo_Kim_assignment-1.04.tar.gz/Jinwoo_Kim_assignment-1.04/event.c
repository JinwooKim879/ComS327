#include <stdio.h>
#include <stdlib.h>
#include "dungeon.h"
#include "event.h"
#include "npc.h"


void event_delete(void *e)
{
  event_t *event = e;

  switch (event->type) {
  case turn_up:
    MOB_ALIVE(event->c);
    break;
  }

  free(event);
}

static uint32_t increment()
{
  static uint32_t num;
  return ++num;
}

event_t *update_event(dungeon_t *d, event_t *event, uint32_t add)
{
  event->time = d->time + add;
  event->sequence = increment();
  return event;
}

int32_t compare_events(const void *a, const void *b)
{
  uint32_t difference;
  difference = (((event_t *) a)->time -((event_t *) b)->time);
  if (difference)
    {
      return difference;
    } else {
    return  (((event_t *) a)->sequence - ((event_t *) b)->sequence);
      }
}

event_t *event_set(dungeon_t *d, event_type_t etype, void *vd, uint32_t add)
{
  event_t *event;
  event = malloc(sizeof (*event));
  event->type = etype;
  event->time = d->time + add;
  event->sequence = increment();
  switch (etype) 
    {
    case turn_up:
      event->c = vd;
    }
  return event;
}




