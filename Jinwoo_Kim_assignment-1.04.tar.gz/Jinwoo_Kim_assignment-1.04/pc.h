#ifndef PC_H
# define PC_H

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include "dims.h"
typedef struct dungeon dungeon_t;
typedef struct pc {
} pc_t;
void ISDEAD(pc_t *pc);
uint32_t ISPC(dungeon_t *d);
void starting(dungeon_t *d);
#endif
