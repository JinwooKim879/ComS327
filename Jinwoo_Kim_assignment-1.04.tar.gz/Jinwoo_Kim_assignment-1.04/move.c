#include "move.h"
#include "dungeon.h"
#include "heap.h"
#include "move.h"
#include "npc.h"
#include "pc.h"
#include <unistd.h>
#include <stdlib.h>
#include <assert.h>
#include "utils.h"
#include "path.h"
#include "event.h"


void set_event(dungeon_t *d)
{
  event_t *e;
  e = malloc(sizeof (*e));
  e->type = turn_up;
  e->time = d->time + (1000/d->pc.speed);
  e->sequence = 0;
  e->c = &d->pc;
  heap_insert(&d->events, e);
}

void kill(dungeon_t *d, character_t *c)
{
  c->alive = 0;
  if (c != &d->pc) {
    d->num_monsters--;
  }
}

uint32_t at_edge(dungeon_t *d, pair_t dir)
{
  dir[dim_y] = dir[dim_x] = 0;

  if (cornor(d, &d->pc) && dir[dim_x] != ter_floor && dir[dim_y] != ter_floor) {
    
    if (mapxy(d->pc.position[dim_x] - 1, d->pc.position[dim_y]) == ter_wall_immutable){
      dir[dim_x] = 1;
    } else {
      dir[dim_x] = -1;
    }
    
    if (mapxy(d->pc.position[dim_x], d->pc.position[dim_y] - 1) == ter_wall_immutable){
      dir[dim_y] = 1;
    } else {
      dir[dim_y] = -1;
    }

  } else {
    closer(&d->pc, dir);
  }

  return 0;
}

void moves(dungeon_t *d)
{

  event_t *event;

  pair_t next;

  character_t *c;


  if (ISPC(d)) {
    set_event(d);
  }

  while (ISPC(d) 
         && (event = heap_remove_min(&d->events)) 
         && ((event->type != turn_up) 
         || (event->c != &d->pc))) {
    d->time = event->time;
    if (event->type == turn_up) {c = event->c;}
    if (!c->alive) {
      if (d->character[c->position[dim_y]][c->position[dim_x]] == c) {
        d->character[c->position[dim_y]][c->position[dim_x]] = NULL;
      }
      if (c != &d->pc) { event_delete(event); }
      continue;
    }

    MOP_move_select(d, c, next);
    if (charpair(next) 
        && ((next[dim_y] != c->position[dim_y]) 
        || (next[dim_x] != c->position[dim_x]))) {
      kill(d, charpair(next));
    } else {
      d->character[c->position[dim_y]][c->position[dim_x]] = NULL;
      c->position[dim_y] = next[dim_y];
      c->position[dim_x] = next[dim_x];
      d->character[c->position[dim_y]][c->position[dim_x]] = c;
    }
    heap_insert(&d->events, update_event(d, event, 1000 / c->speed));
  }

  if (ISPC(d) && event->c == &d->pc) {
    c = event->c;
    d->time = event->time;
    event->c = NULL;
    event_delete(event);
    at_edge(d, next);
    next[dim_x] = next[dim_x] + c->position[dim_x];
    next[dim_y] = next[dim_y] + c->position[dim_y];
    if (mappair(next) <= ter_floor) {
      mappair(next) = ter_floor_hall;
    }
    if (charpair(next) 
        && ((next[dim_y] != c->position[dim_y]) 
        || (next[dim_x] != c->position[dim_x]))) {
      kill(d, charpair(next));
    } else {
      d->character[c->position[dim_y]][c->position[dim_x]] = NULL;
      c->position[dim_y] = next[dim_y];
      c->position[dim_x] = next[dim_x];
      d->character[c->position[dim_y]][c->position[dim_x]] = c;
    }
    dijkstra(d);
    dijkstra_tunnel(d);
  }
}

uint32_t cornor(dungeon_t *d, character_t *c)
{
  uint32_t count;

  count = 0;
  count = count + (mapxy(c->position[dim_x] - 1, c->position[dim_y]) == ter_wall_immutable);
  count = count + (mapxy(c->position[dim_x] + 1, c->position[dim_y]) == ter_wall_immutable);
  count = count + (mapxy(c->position[dim_x], c->position[dim_y] - 1) == ter_wall_immutable);
  count = count + (mapxy(c->position[dim_x], c->position[dim_y] + 1) == ter_wall_immutable);
  return count > 1;
}

void closer(character_t *c, pair_t dir)
{
  dir[dim_x] = 0;
  dir[dim_y] = 0;
  if (c->position[dim_x] != 1 && c->position[dim_x] != DUNGEON_X - 2) {
    if (c->position[dim_x] > DUNGEON_X - c->position[dim_x]){
      dir[dim_x] = 1;
    } else {
      dir[dim_x] = -1;
    }
  }
  if (c->position[dim_y] != 1 && c->position[dim_y] != DUNGEON_Y - 2) {
    if (c->position[dim_y] > DUNGEON_Y - c->position[dim_y]){
      dir[dim_y] = 1;
    } else {
      dir[dim_y] = -1;
    }
  }
}


